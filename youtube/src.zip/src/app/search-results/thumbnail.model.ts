export default class ThumbnailItem {
  constructor(public url: string, public width: number, public height: number) {
    this.url = url;
    this.width = width;
    this.height = height;
  }
}
