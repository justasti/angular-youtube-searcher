const environment = {
  production: true,
};

export default environment;
